function [ f ] = InitialCondition( x )
    t = 0;
    f = exp(1).^(0.5E0.*x).*(1+t.^2);
end