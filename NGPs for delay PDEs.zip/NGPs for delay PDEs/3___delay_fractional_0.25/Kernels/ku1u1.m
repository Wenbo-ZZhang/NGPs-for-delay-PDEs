function K=ku1u1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
alpha = ModelInfo.alpha;
logsigmau = hyp(1);
logthetau = hyp(2);
logsigmat = hyp(3);
logthetat = hyp(4);
logsigmaf = hyp(5);
logthetaf = hyp(6);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';


if i==0
    
    K = dt.^2.*exp(1).^(logsigmaf+(-1/2).*exp(1).^((-1).*logthetaf).*(x+(-1).*y).^2)+dt.^2.*(3.*exp(1).^(logsigmat+(-2).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2)+(-5).*exp(1).^(logsigmat+(-3).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*(x+(-1).*y).^2+((-1).*exp(1).^(logsigmat+(-3).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2)+exp(1).^(logsigmat+(-4).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*(x+(-1).*y).^2).*(x+(-1).*y).^2)+exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*(exp(1).^logthetau).^(1/2).*pi.^(-1/2).*(exp(1).^((-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*pi.^(1/2)+2.^alpha.*dt.^2.*(exp(1).^logthetau).^((-1).*alpha).*gamma((1/2)+alpha).*kummer((1/2)+alpha,(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^(1+(1/2).*alpha).*dt.*(exp(1).^logthetau).^((-1/2).*alpha).*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2));

    K = real(K);

    
    
elseif i== 1
    
    K = exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*(exp(1).^logthetau).^(1/2).*pi.^(-1/2).*(exp(1).^((-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*pi.^(1/2)+2.^alpha.*dt.^2.*(exp(1).^logthetau).^((-1).*alpha).*gamma((1/2)+alpha).*kummer((1/2)+alpha,(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^(1+(1/2).*alpha).*dt.*(exp(1).^logthetau).^((-1/2).*alpha).*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2));

    K = real(K);

elseif i== 2
    
    K = exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*(exp(1).^logthetau).^(1/2).*pi.^(-1/2).*((1/2).*exp(1).^((-1).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*pi.^(1/2).*(x+(-1).*y).^2+(-1).*2.^alpha.*alpha.*dt.^2.*(exp(1).^logthetau).^((-1).*alpha).*gamma((1/2)+alpha).*kummer((1/2)+alpha,(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+2.^((1/2).*alpha).*alpha.*dt.*(exp(1).^logthetau).^((-1/2).*alpha).*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+2.^alpha.*((1/2)+alpha).*dt.^2.*(exp(1).^logthetau).^((-1)+(-1).*alpha).*(x+(-1).*y).^2.*gamma((1/2)+alpha).*kummer((3/2)+alpha,(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((1/2).*alpha).*(1+alpha).*dt.*(exp(1).^logthetau).^((-1)+(-1/2).*alpha).*(x+(-1).*y).^2.*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer(1+(1/2).*(1+alpha),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2));

    K = real(K);

elseif i== 3
    
    K =dt.^2.*(3.*exp(1).^(logsigmat+(-2).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2)+(-5).*exp(1).^(logsigmat+(-3).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*(x+(-1).*y).^2+((-1).*exp(1).^(logsigmat+(-3).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2)+exp(1).^(logsigmat+(-4).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*(x+(-1).*y).^2).*(x+(-1).*y).^2);

    
elseif i== 4
    
    K = dt.^2.*(3.*exp(1).^(logsigmat+(-2).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*((-2)+(1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2)+(-5).*exp(1).^(logsigmat+(-3).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*((-3)+(1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*(x+(-1).*y).^2+((-1).*exp(1).^(logsigmat+(-3).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*((-3)+(1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2)+exp(1).^(logsigmat+(-4).*logthetat+(-1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*((-4)+(1/2).*exp(1).^((-1).*logthetat).*(x+(-1).*y).^2).*(x+(-1).*y).^2).*(x+(-1).*y).^2);

elseif i== 5
    
    K = dt.^2.*exp(1).^(logsigmaf+(-1/2).*exp(1).^((-1).*logthetaf).*(x+(-1).*y).^2);
    
elseif i== 6
    
    K = (1/2).*dt.^2.*exp(1).^(logsigmaf+(-1).*logthetaf+(-1/2).*exp(1).^((-1).*logthetaf).*(x+(-1).*y).^2).*(x+(-1).*y).^2;
else
    K = zeros(n_x,n_y);
end

end