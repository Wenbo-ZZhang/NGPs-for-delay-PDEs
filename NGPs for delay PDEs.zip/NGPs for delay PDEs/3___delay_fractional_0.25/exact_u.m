function [f] = exact_u( x, t )

    f = exp(1).^(0.5E0.*x).*(1+t.^2);
end

