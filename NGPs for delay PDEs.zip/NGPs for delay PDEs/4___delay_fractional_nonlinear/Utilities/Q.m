function [f] = Q(x)

    f = 1+x;
    
end