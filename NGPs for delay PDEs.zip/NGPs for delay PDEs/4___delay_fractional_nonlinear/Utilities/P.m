function [f] = P(x)

    f = 1+x;
    
end