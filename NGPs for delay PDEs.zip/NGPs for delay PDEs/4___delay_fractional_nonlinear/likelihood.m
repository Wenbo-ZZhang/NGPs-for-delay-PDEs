function [NLML,D_NLML]=likelihood(hyp)

global ModelInfo
x_u = ModelInfo.x_u;
x_lb = ModelInfo.x_lb;
x_ub = ModelInfo.x_ub;
x_f = ModelInfo.x_f;
x_t = ModelInfo.x_t;

u_t = ModelInfo.u_t;
f = ModelInfo.f;
u = ModelInfo.u;
w_lb = ModelInfo.w_lb;
w_ub = ModelInfo.w_ub;

y=[w_lb; w_ub; u_t; f; u];

jitter = ModelInfo.jitter;

sigma_n = exp(hyp(end));
   
n_u = size(x_u, 1);
n_f = size(x_f, 1);
n_b = 1;
n_t = size(x_t, 1);
n = 2*n_b + n_t + n_f + n_u;

Kw1w1 = kw1w1(x_lb, x_lb, hyp, 0);
Kw2w2 = kw2w2(x_ub, x_ub, hyp, 0);
Ktt = ktt(x_t, x_t, hyp, 0);
Kff = kff(x_f, x_f, hyp, 0);

Kw1w2 = kw1w2(x_lb, x_ub, hyp, 0);
Kw1u1 = kw1u1(x_lb, x_u, hyp, 0);
Kw2u1 = kw2u1(x_ub, x_u, hyp, 0);
Ktu1 = ktu1(x_t, x_u, hyp, 0);
Kfu1 = kfu1(x_f, x_u, hyp, 0);

Ku1u1 = ku1u1(x_u, x_u, hyp, 0) + eye(n_u).*sigma_n;

K = [Kw1w1         Kw1w2         zeros(1, n_t)   zeros(1, n_f)   Kw1u1;
     Kw1w2'        Kw2w2         zeros(1, n_t)   zeros(1, n_f)   Kw2u1;
     zeros(n_t, 1) zeros(n_t, 1) Ktt             zeros(n_t, n_f) Ktu1;
     zeros(n_f, 1) zeros(n_f, 1) zeros(n_f, n_t) Kff             Kfu1;
     Kw1u1'        Kw2u1'        Ktu1'           Kfu1'           Ku1u1];

K = K + eye(n).*jitter;

% Cholesky factorisation
[L,p]=chol(K,'lower');

ModelInfo.L = L;

if p > 0
    fprintf(1,'Covariance is ill-conditioned\n');
    size(L)
    size(K)
end

alpha = L'\(L\y);
NLML = 0.5*y'*alpha + sum(log(diag(L))) + log(2*pi)*n/2;


D_NLML = 0*hyp;
Q =  L'\(L\eye(n)) - alpha*alpha';
for i=1:6
    Kw1w1 = kw1w1(x_lb, x_lb, hyp, i);
    Kw2w2 = kw2w2(x_ub, x_ub, hyp, i);
    Ktt = ktt(x_t, x_t, hyp, i);
    Kff = kff(x_f, x_f, hyp, i);

    Kw1w2 = kw1w2(x_lb, x_ub, hyp, i);
    Kw1u1 = kw1u1(x_lb, x_u, hyp, i);
    Kw2u1 = kw2u1(x_ub, x_u, hyp, i);
    Ktu1 = ktu1(x_t, x_u, hyp, i);
    Kfu1 = kfu1(x_f, x_u, hyp, i);

    Ku1u1 = ku1u1(x_u, x_u, hyp, i);



    DK = [Kw1w1         Kw1w2         zeros(1, n_t)   zeros(1, n_f)   Kw1u1;
          Kw1w2'        Kw2w2         zeros(1, n_t)   zeros(1, n_f)   Kw2u1;
          zeros(n_t, 1) zeros(n_t, 1) Ktt             zeros(n_t, n_f) Ktu1;
          zeros(n_f, 1) zeros(n_f, 1) zeros(n_f, n_t) Kff             Kfu1;
          Kw1u1'        Kw2u1'        Ktu1'           Kfu1'           Ku1u1];

    D_NLML(i) = sum(sum(Q.*DK))/2;
end

D_NLML(end) = sigma_n*trace(Q(n_b+n_t+n_f+1:end,n_b+n_t+n_f+1:end))/2;