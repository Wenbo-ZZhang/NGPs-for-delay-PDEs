set(0,'defaulttextinterpreter','latex')
addpath ./export_fig
T = 1;
dt = 0.01;
dx = 0.1;



nsteps = T/dt;
D =load('errorD.txt');
R =load('errorR.txt');
M =load('errorM.txt');
%semilogy((1:nsteps)*dt,data,'b','LineWidth',3);
%semilogy((1:nsteps)*dt,D,'b',(1:nsteps)*dt, (1:nsteps)*dt,'--r','LineWidth',3);
semilogy((1:nsteps)*dt,D,'k',(1:nsteps)*dt,R,'b',(1:nsteps)*dt,M,'r','LineWidth',2);
%plot((1:nsteps)*dt,D,'b','LineWidth',3);
%hold
%plot((1:nsteps)*dt,D,'y','LineWidth',3);
%plot((1:nsteps)*dt,R,'g','LineWidth',3);
%plot((1:nsteps)*dt,M,'r','LineWidth',3);
xlabel('$t$')
ylabel('Error')
axis tight
ylim([0 0.05]);


set(gcf,'unit','normalized','position',[0.2,0.2,0.55,0.3]);


%h = legend('Error','$\Delta{t}$','Location', 'SouthEast');
%h = legend('$L_{2}$-$error$','$E_{\infty}$','Location', 'NorthEast');
h = legend('$E_{\infty}$ for D','$E_{\infty}$ for R','$E_{\infty}$ for M','Location', 'NorthEast');
set(h,'Interpreter','latex');
%axis tight
set(gca,'FontName','Times New Roman','FontSize',14);
set(gcf, 'Color', 'w');

%tit = sprintf('Time versus maximum absolute error $E_{\\infty}$');
%set(gca,'FontName','Times New Roman','FontSize',14);
%title(tit);