function K=kuu1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
alpha = ModelInfo.alpha;
beta = ModelInfo.beta;
u = ModelInfo.u;
logsigmau = hyp(1);
logthetau = hyp(2);


n_x = size(x,1);
n_y = size(y,1);

%u1nx = (sin(u).*(1-x))*ones(1,n_y);
u1ny = ones(n_x,1)*(sin(u).*(1-y))';

%u2nx = ((u.^0.5).*sin(2*pi*x))*ones(1,n_y);
u2ny = ones(n_x,1)*((u.^0.5).*sin(2*pi*y))';

x = x*ones(1,n_y);
y = ones(n_x,1)*y';


if i==0
    
    K = exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*pi.^(-1/2).*(exp(1).^((-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(exp(1).^logthetau).^(1/2).*pi.^(1/2)+(-1).*2.^((1/2).*alpha).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*alpha).*u1ny.*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((1/2).*beta).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*beta).*u2ny.*cos((1/2).*beta.*pi).*gamma((1/2).*(1+beta)).*kummer((1/2).*(1+beta),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+2.^(1/2).*dt.*(x+(-1).*y).*((-1).*2.^((1/2).*alpha).*(exp(1).^logthetau).^((-1/2).*alpha).*u1ny.*gamma(1+(1/2).*alpha).*kummer((1/2).*(2+alpha),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*alpha.*pi)+(-1).*2.^((1/2).*beta).*(exp(1).^logthetau).^((-1/2).*beta).*u2ny.*gamma(1+(1/2).*beta).*kummer((1/2).*(2+beta),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*beta.*pi)));


    K = real(K);

elseif i== 1
    
    K = exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*pi.^(-1/2).*(exp(1).^((-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(exp(1).^logthetau).^(1/2).*pi.^(1/2)+(-1).*2.^((1/2).*alpha).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*alpha).*u1ny.*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((1/2).*beta).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*beta).*u2ny.*cos((1/2).*beta.*pi).*gamma((1/2).*(1+beta)).*kummer((1/2).*(1+beta),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+2.^(1/2).*dt.*(x+(-1).*y).*((-1).*2.^((1/2).*alpha).*(exp(1).^logthetau).^((-1/2).*alpha).*u1ny.*gamma(1+(1/2).*alpha).*kummer((1/2).*(2+alpha),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*alpha.*pi)+(-1).*2.^((1/2).*beta).*(exp(1).^logthetau).^((-1/2).*beta).*u2ny.*gamma(1+(1/2).*beta).*kummer((1/2).*(2+beta),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*beta.*pi)));


    K = real(K);
    
elseif i== 2
    
    K = (-1/2).*exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*pi.^(-1/2).*(exp(1).^((-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(exp(1).^logthetau).^(1/2).*pi.^(1/2)+(-1).*2.^((1/2).*alpha).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*alpha).*u1ny.*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((1/2).*beta).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*beta).*u2ny.*cos((1/2).*beta.*pi).*gamma((1/2).*(1+beta)).*kummer((1/2).*(1+beta),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+2.^(1/2).*dt.*(x+(-1).*y).*((-1).*2.^((1/2).*alpha).*(exp(1).^logthetau).^((-1/2).*alpha).*u1ny.*gamma(1+(1/2).*alpha).*kummer((1/2).*(2+alpha),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*alpha.*pi)+(-1).*2.^((1/2).*beta).*(exp(1).^logthetau).^((-1/2).*beta).*u2ny.*gamma(1+(1/2).*beta).*kummer((1/2).*(2+beta),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*beta.*pi)))+exp(1).^logsigmau.*(exp(1).^((-1).*logthetau)).^(1/2).*pi.^(-1/2).*((1/2).*exp(1).^((-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(exp(1).^logthetau).^(1/2).*pi.^(1/2)+(1/2).*exp(1).^((-1).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(exp(1).^logthetau).^(1/2).*pi.^(1/2).*(x+(-1).*y).^2+(-1).*2.^((1/2).*alpha).*((1/2)+(-1/2).*alpha).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*alpha).*u1ny.*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer((1/2).*(1+alpha),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((-1)+(1/2).*alpha).*(1+alpha).*dt.*(exp(1).^logthetau).^((-1/2)+(-1/2).*alpha).*u1ny.*(x+(-1).*y).^2.*cos((1/2).*alpha.*pi).*gamma((1/2).*(1+alpha)).*kummer(1+(1/2).*(1+alpha),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((1/2).*beta).*((1/2)+(-1/2).*beta).*dt.*(exp(1).^logthetau).^((1/2)+(-1/2).*beta).*u2ny.*cos((1/2).*beta.*pi).*gamma((1/2).*(1+beta)).*kummer((1/2).*(1+beta),(1/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+(-1).*2.^((-1)+(1/2).*beta).*(1+beta).*dt.*(exp(1).^logthetau).^((-1/2)+(-1/2).*beta).*u2ny.*(x+(-1).*y).^2.*cos((1/2).*beta.*pi).*gamma((1/2).*(1+beta)).*kummer(1+(1/2).*(1+beta),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2)+2.^(1/2).*dt.*(x+(-1).*y).*(2.^((-1)+(1/2).*alpha).*alpha.*(exp(1).^logthetau).^((-1/2).*alpha).*u1ny.*gamma(1+(1/2).*alpha).*kummer((1/2).*(2+alpha),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*alpha.*pi)+(-1/3).*2.^((-1)+(1/2).*alpha).*(2+alpha).*(exp(1).^logthetau).^((-1)+(-1/2).*alpha).*u1ny.*(x+(-1).*y).^2.*gamma(1+(1/2).*alpha).*kummer(1+(1/2).*(2+alpha),(5/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*alpha.*pi)+2.^((-1)+(1/2).*beta).*beta.*(exp(1).^logthetau).^((-1/2).*beta).*u2ny.*gamma(1+(1/2).*beta).*kummer((1/2).*(2+beta),(3/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*beta.*pi)+(-1/3).*2.^((-1)+(1/2).*beta).*(2+beta).*(exp(1).^logthetau).^((-1)+(-1/2).*beta).*u2ny.*(x+(-1).*y).^2.*gamma(1+(1/2).*beta).*kummer(1+(1/2).*(2+beta),(5/2),(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*sin((1/2).*beta.*pi)));

  
    K = real(K);
    
else
    K = zeros(n_x,n_y);
end

end