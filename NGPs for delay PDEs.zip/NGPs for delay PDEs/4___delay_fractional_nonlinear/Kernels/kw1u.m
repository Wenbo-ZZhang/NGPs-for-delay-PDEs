function K=kw1u(x, y, hyp, i)

global ModelInfo
dt = ModelInfo.dt;
u = ModelInfo.u;
logsigmau = hyp(1);
logthetau = hyp(2);


n_x = size(x,1);
n_y = size(y,1);

lbx1 = ModelInfo.lbx1;
lbx2 = ModelInfo.lbx2;
lby1 = ModelInfo.lby1;
lby2 = ModelInfo.lby2;
ubx1 = ModelInfo.ubx1;
ubx2 = ModelInfo.ubx2;
uby1 = ModelInfo.uby1;
uby2 = ModelInfo.uby2;

x = x*ones(1,n_y);
y = ones(n_x,1)*y';


if i==0
    
    K = exp(1).^(logsigmau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y) ...
  .^2).*lbx2+(-1).*exp(1).^(logsigmau+(-1).*logthetau+(-1/2).*exp(1) ...
  .^((-1).*logthetau).*(x+(-1).*y).^2).*lbx1.*(x+(-1).*y);
    
elseif i== 1
    
    K = exp(1).^(logsigmau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y) ...
  .^2).*lbx2+(-1).*exp(1).^(logsigmau+(-1).*logthetau+(-1/2).*exp(1) ...
  .^((-1).*logthetau).*(x+(-1).*y).^2).*lbx1.*(x+(-1).*y);
    
elseif i== 2
    
    K = (-1).*exp(1).^(logsigmau+(-1).*logthetau+(-1/2).*exp(1).^((-1).* ...
  logthetau).*(x+(-1).*y).^2).*lbx1.*((-1)+(1/2).*exp(1).^((-1).* ...
  logthetau).*(x+(-1).*y).^2).*(x+(-1).*y)+(1/2).*exp(1).^( ...
  logsigmau+(-1).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+( ...
  -1).*y).^2).*lbx2.*(x+(-1).*y).^2;

else
    K = zeros(n_x,n_y);
end

end