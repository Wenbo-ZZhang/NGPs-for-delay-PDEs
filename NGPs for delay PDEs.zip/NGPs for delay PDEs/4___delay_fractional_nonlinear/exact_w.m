function [f] = exact_w( x, t, c)
    if c == 1
        f = exp(1).^(0.5E0.*x).*t.^2.*(1+t.^2)+0.5E0.*exp(1).^(0.5E0.*x).*(1+ ...
  t).*(1+t.^2);
    elseif c == 2 
        f = 0.5E0.*exp(1).^(0.5E0.*x).*(1+t).^2.*(1+t.^2)+2.*exp(1).^(0.5E0.* ...
  x).*(1+t.^2).*cos(t);
    end
    
end

