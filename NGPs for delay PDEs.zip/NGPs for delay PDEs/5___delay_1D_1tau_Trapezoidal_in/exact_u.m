function [f] = exact_u( x, t )
    f = exp(1).^((-1).*t).*(cos(x)+sin(x));
end

