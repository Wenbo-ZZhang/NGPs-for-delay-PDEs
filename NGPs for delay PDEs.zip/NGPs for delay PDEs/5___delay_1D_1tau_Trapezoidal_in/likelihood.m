function [NLML,D_NLML]=likelihood(hyp)

global ModelInfo

x_b = ModelInfo.x_b;
x_b1 = ModelInfo.x_b1;
x_t = ModelInfo.x_t;
x_t1 = ModelInfo.x_t1;
x_u = ModelInfo.x_u;
x_f = ModelInfo.x_f;
x_f1 = ModelInfo.x_f1;

u_b = ModelInfo.u_b;
u_b1 = ModelInfo.u_b1;
u_t = ModelInfo.u_t;
u_t1 = ModelInfo.u_t1;
u_f = ModelInfo.u_f;
u_f1 = ModelInfo.u_f1;
u = ModelInfo.u;

y=[u_b; u_t; u_b1; u_t1; u_f; u_f1; u; u];

jitter = ModelInfo.jitter;

sigma_n = exp(hyp(end));
   
n_u = size(x_u, 1);
n_b = size(x_b, 1);
n_b1 = size(x_b1, 1);
n_t = size(x_t, 1);
n_t1 = size(x_t1, 1);
n_f = size(x_f, 1);
n_f1 = size(x_f1, 1);
n = n_b + n_b1 + n_t + n_t1 + n_f + n_f1 + 2*n_u;

Kbb = kuu(x_b, x_b, hyp, 0);
Ktt = ktt(x_t, x_t, hyp, 0);
Kb1b1 = ku1u1(x_b1, x_b1, hyp, 0);
Kt1t1 = kt1t1(x_t1, x_t1, hyp, 0);
Kff = kff(x_f, x_f, hyp, 0);
Kf1f1 = kf1f1(x_f1, x_f1, hyp, 0);

Kbu1 = zeros(n_b, n_u);
Kbu2 = kuu2(x_b, x_u, hyp, 0);

Ktu1 = zeros(n_t, n_u);
Ktu2 = ktu2(x_t, x_u, hyp, 0);

Kb1u1 = ku1u1(x_b1, x_u, hyp, 0);
Kb1u2 = ku1u2(x_b1, x_u, hyp, 0);

Kt1u1 = zeros(n_t1, n_u);
Kt1u2 = kt1u2(x_t1, x_u, hyp, 0);

Kfu2 = kfu2(x_f, x_u, hyp, 0);
Kf1u2 = kf1u2(x_f1, x_u, hyp, 0);

Ku1u1 = ku1u1(x_u, x_u, hyp, 0) + eye(n_u).*sigma_n;
Ku1u2 = ku1u2(x_u, x_u, hyp, 0);
Ku2u2 = ku2u2(x_u, x_u, hyp, 0) + eye(n_u).*sigma_n;



K = [Kbb zeros(n_b, n_t) zeros(n_b, n_b1) zeros(n_b, n_t1) zeros(n_b,n_f) zeros(n_b,n_f1) Kbu1 Kbu2;
    zeros(n_t, n_b) Ktt zeros(n_t, n_b1) zeros(n_t, n_t1) zeros(n_t,n_f) zeros(n_t,n_f1) Ktu1 Ktu2;
    zeros(n_b1, n_b) zeros(n_b1, n_t) Kb1b1 zeros(n_b1, n_t1) zeros(n_b1,n_f) zeros(n_b1,n_f1) Kb1u1 Kb1u2;
    zeros(n_t1, n_b) zeros(n_t1, n_t) zeros(n_t1, n_b1) Kt1t1 zeros(n_t1,n_f) zeros(n_t1,n_f1) Kt1u1 Kt1u2;
    zeros(n_f,n_b) zeros(n_f,n_t) zeros(n_f,n_b1) zeros(n_f,n_t1) Kff zeros(n_f,n_f1) zeros(n_f,n_u) Kfu2;
    zeros(n_f1,n_b) zeros(n_f1,n_t) zeros(n_f1,n_b1) zeros(n_f1,n_t1) zeros(n_f1,n_f) Kf1f1 zeros(n_f1,n_u) Kf1u2;
    Kbu1' Ktu1' Kb1u1' Kt1u1' zeros(n_u,n_f) zeros(n_u,n_f1) Ku1u1 Ku1u2;
    Kbu2' Ktu2' Kb1u2' Kt1u2' Kfu2' Kf1u2' Ku1u2' Ku2u2];

K = K + eye(n).*jitter;

% Cholesky factorisation
[L,p]=chol(K,'lower');

ModelInfo.L = L;

if p > 0
    fprintf(1,'Covariance is ill-conditioned\n');
    det(K)
    size(K)
    size(L)
    size(y)
end

alpha = L'\(L\y);
NLML = 0.5*y'*alpha + sum(log(diag(L))) + log(2*pi)*n/2;


D_NLML = 0*hyp;
Q =  L'\(L\eye(n)) - alpha*alpha';
for i=1:12
    Kbb = kuu(x_b, x_b, hyp, i);
    Ktt = ktt(x_t, x_t, hyp, i);
Kb1b1 = ku1u1(x_b1, x_b1, hyp, i);
Kt1t1 = kt1t1(x_t1, x_t1, hyp, i);
Kff = kff(x_f, x_f, hyp, i);
Kf1f1 = kf1f1(x_f1, x_f1, hyp, i);

Kbu1 = zeros(n_b, n_u);
Kbu2 = kuu2(x_b, x_u, hyp, i);
Ktu1 = zeros(n_t, n_u);
Ktu2 = ktu2(x_t, x_u, hyp, i);
Kb1u1 = ku1u1(x_b1, x_u, hyp, i);
Kb1u2 = ku1u2(x_b1, x_u, hyp, i);
Kt1u1 = zeros(n_t1, n_u);
Kt1u2 = kt1u2(x_t1, x_u, hyp, i);

Kfu2 = kfu2(x_f, x_u, hyp, i);
Kf1u2 = kf1u2(x_f1, x_u, hyp, i);

Ku1u1 = ku1u1(x_u, x_u, hyp, i);
Ku1u2 = ku1u2(x_u, x_u, hyp, i);
Ku2u2 = ku2u2(x_u, x_u, hyp, i);



DK = [Kbb zeros(n_b, n_t) zeros(n_b, n_b1) zeros(n_b, n_t1) zeros(n_b,n_f) zeros(n_b,n_f1) Kbu1 Kbu2;
    zeros(n_t, n_b) Ktt zeros(n_t, n_b1) zeros(n_t, n_t1) zeros(n_t,n_f) zeros(n_t,n_f1) Ktu1 Ktu2;
    zeros(n_b1, n_b) zeros(n_b1, n_t) Kb1b1 zeros(n_b1, n_t1) zeros(n_b1,n_f) zeros(n_b1,n_f1) Kb1u1 Kb1u2;
    zeros(n_t1, n_b) zeros(n_t1, n_t) zeros(n_t1, n_b1) Kt1t1 zeros(n_t1,n_f) zeros(n_t1,n_f1) Kt1u1 Kt1u2;
    zeros(n_f,n_b) zeros(n_f,n_t) zeros(n_f,n_b1) zeros(n_f,n_t1) Kff zeros(n_f,n_f1) zeros(n_f,n_u) Kfu2;
    zeros(n_f1,n_b) zeros(n_f1,n_t) zeros(n_f1,n_b1) zeros(n_f1,n_t1) zeros(n_f1,n_f) Kf1f1 zeros(n_f1,n_u) Kf1u2;
    Kbu1' Ktu1' Kb1u1' Kt1u1' zeros(n_u,n_f) zeros(n_u,n_f1) Ku1u1 Ku1u2;
    Kbu2' Ktu2' Kb1u2' Kt1u2' Kfu2' Kf1u2' Ku1u2' Ku2u2];

    D_NLML(i) = sum(sum(Q.*DK))/2;
end

D_NLML(end) = sigma_n*trace(Q(n_b + n_b1 + n_t + n_t1 + n_f + n_f1 + 1:end, n_b + n_b1 + n_t + n_t1 + n_f + n_f1  + 1:end))/2;