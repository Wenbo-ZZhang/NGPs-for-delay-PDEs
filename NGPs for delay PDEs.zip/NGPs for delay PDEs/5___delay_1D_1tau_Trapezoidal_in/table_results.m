%clc
e1 = load("error1.txt");
dt = 0.00625;
data = [];
for i = 1:(1/dt)
    if mod(i,(0.2/dt))==0
        data =[data, e1(i)] ;
        sprintf('e1=%.6e', e1(i))
    end
end

E=load('error1.txt');
a=max(E);

data =[data, a] ;

sprintf('%.3e & %.3e & %.3e & %.3e & %.3e & %.3e  ', data(1),data(2),data(3),data(4),data(5),data(6))

%save data.txt -ascii data