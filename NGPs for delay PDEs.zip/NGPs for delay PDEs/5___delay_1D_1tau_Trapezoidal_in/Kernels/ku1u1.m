function K=ku1u1(x, y, hyp, i)

logsigmau1 = hyp(5);
logthetau1 = hyp(6);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';

if i==0
    
    K = exp(1).^(logsigmau1+(-1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2);
    
elseif i== 5
    
    K = exp(1).^(logsigmau1+(-1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2);
    
elseif i== 6
    
    K = (1/2).*exp(1).^(logsigmau1+(-1).*logthetau1+(-1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2).*(x+(-1).*y).^2;
else
    K = zeros(n_x,n_y);
end

end