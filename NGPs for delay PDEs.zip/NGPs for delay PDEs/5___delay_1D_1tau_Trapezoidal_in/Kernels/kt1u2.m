function K=kt1u2(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
alpha = ModelInfo.alpha;
beta = ModelInfo.beta;
logsigmat1 = hyp(7);
logthetat1 = hyp(8);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';

if i==0
    
    K = (-0.5E0).*beta.*dt.*((-1).*exp(1).^(logsigmat1+(-1).*logthetat1+( ...
  -1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2)+exp(1).^( ...
  logsigmat1+(-2).*logthetat1+(-1/2).*exp(1).^((-1).*logthetat1).*( ...
  x+(-1).*y).^2).*(x+(-1).*y).^2);
    
elseif i== 7
    
    K = (-0.5E0).*beta.*dt.*((-1).*exp(1).^(logsigmat1+(-1).*logthetat1+( ...
  -1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2)+exp(1).^( ...
  logsigmat1+(-2).*logthetat1+(-1/2).*exp(1).^((-1).*logthetat1).*( ...
  x+(-1).*y).^2).*(x+(-1).*y).^2);
    
elseif i== 8
    
    K = (-0.5E0).*beta.*dt.*((-1).*exp(1).^(logsigmat1+(-1).*logthetat1+( ...
  -1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2).*((-1)+(1/2).* ...
  exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2)+exp(1).^(logsigmat1+( ...
  -2).*logthetat1+(-1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y) ...
  .^2).*((-2)+(1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2).*( ...
  x+(-1).*y).^2);
else
    K = zeros(n_x,n_y);
end

end