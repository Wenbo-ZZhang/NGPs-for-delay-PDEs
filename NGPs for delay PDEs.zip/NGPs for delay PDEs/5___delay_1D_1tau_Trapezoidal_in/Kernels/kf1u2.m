function K=kf1u2(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
alpha = ModelInfo.alpha;
beta = ModelInfo.beta;
logsigmaf1 = hyp(11);
logthetaf1 = hyp(12);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';

if i==0
    
    K = (-0.5E0).*dt.*exp(1).^(logsigmaf1+(-1/2).*exp(1).^((-1).* ...
  logthetaf1).*(x+(-1).*y).^2);
    
elseif i== 11
    
    K = (-0.5E0).*dt.*exp(1).^(logsigmaf1+(-1/2).*exp(1).^((-1).* ...
  logthetaf1).*(x+(-1).*y).^2);
    
elseif i== 12
    
    K = (-0.25E0).*dt.*exp(1).^(logsigmaf1+(-1).*logthetaf1+(-1/2).*exp(1) ...
  .^((-1).*logthetaf1).*(x+(-1).*y).^2).*(x+(-1).*y).^2;
else
    K = zeros(n_x,n_y);
end

end