function K=ku1u2(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
alpha = ModelInfo.alpha;
beta = ModelInfo.beta;
logsigmau1 = hyp(5);
logthetau1 = hyp(6);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';

if i==0
    
    K = (-0.5E0).*alpha.*dt.*((-1).*exp(1).^(logsigmau1+(-1).*logthetau1+( ...
  -1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2)+exp(1).^( ...
  logsigmau1+(-2).*logthetau1+(-1/2).*exp(1).^((-1).*logthetau1).*( ...
  x+(-1).*y).^2).*(x+(-1).*y).^2);
    
elseif i== 5
    
    K = (-0.5E0).*alpha.*dt.*((-1).*exp(1).^(logsigmau1+(-1).*logthetau1+( ...
  -1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2)+exp(1).^( ...
  logsigmau1+(-2).*logthetau1+(-1/2).*exp(1).^((-1).*logthetau1).*( ...
  x+(-1).*y).^2).*(x+(-1).*y).^2);
    
elseif i== 6
    
    K = (-0.5E0).*alpha.*dt.*((-1).*exp(1).^(logsigmau1+(-1).*logthetau1+( ...
  -1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2).*((-1)+(1/2).* ...
  exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2)+exp(1).^(logsigmau1+( ...
  -2).*logthetau1+(-1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y) ...
  .^2).*((-2)+(1/2).*exp(1).^((-1).*logthetau1).*(x+(-1).*y).^2).*( ...
  x+(-1).*y).^2);
else
    K = zeros(n_x,n_y);
end

end