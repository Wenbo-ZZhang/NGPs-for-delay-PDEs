function [Kpred, Kvar] = predictor(x_star)

global ModelInfo

x_b = ModelInfo.x_b;
x_b1 = ModelInfo.x_b1;
x_t = ModelInfo.x_t;
x_t1 = ModelInfo.x_t1;
x_f = ModelInfo.x_f;
x_f1 = ModelInfo.x_f1;
u_f = ModelInfo.u_f;
u_f1 = ModelInfo.u_f1;
x_u = ModelInfo.x_u;


u_b = ModelInfo.u_b;
u_b1 = ModelInfo.u_b1;
u_t = ModelInfo.u_t;
u_t1 = ModelInfo.u_t1;
u = ModelInfo.u;

y=[u_b; u_t; u_b1; u_t1; u_f; u_f1; u; u];

n_star = size(x_star,1);
n_u = size(x_u, 1);
n_b = size(x_b, 1);
n_b1 = size(x_b1, 1);
n_t = size(x_t, 1);
n_t1 = size(x_t1, 1);
n_f = size(x_f, 1);
n_f1 = size(x_f1, 1);

K0 = ModelInfo.K0;
Kt = ModelInfo.Kt;
Kt1 = ModelInfo.Kt1;

S = [zeros(n_b, n_b) zeros(n_b, n_t) zeros(n_b, n_b1) zeros(n_b, n_t1) zeros(n_b, n_f) zeros(n_b, n_f1) zeros(n_b, 2*n_u);
    zeros(n_t, n_b) Kt zeros(n_t, n_b1) zeros(n_t, n_t1) zeros(n_t, n_f) zeros(n_t, n_f1) zeros(n_t, 2*n_u);
    zeros(n_b1, n_b) zeros(n_b1, n_t) zeros(n_b1, n_b1) zeros(n_b1, n_t1) zeros(n_b1, n_f) zeros(n_b1, n_f1) zeros(n_b1, 2*n_u);
    zeros(n_t1, n_b) zeros(n_t1, n_t) zeros(n_t1, n_b1) Kt1 zeros(n_t1, n_f) zeros(n_t1, n_f1) zeros(n_t1, 2*n_u);
    zeros(n_f+n_f1,n_b+n_t+n_b1+n_t1+n_f+n_f1+2*n_u)
    zeros(n_u,n_b+n_t+n_b1+n_t1+n_f+n_f1) K0 K0;
    zeros(n_u,n_b+n_t+n_b1+n_t1+n_f+n_f1) K0 K0];

hyp = ModelInfo.hyp;


K1 = kuu(x_star, x_b, hyp, 0);
K2 = zeros(n_star,n_t+n_b1+n_t1+n_f+n_f1+n_u);
K3 = kuu2(x_star, x_u, hyp, 0);

psi = [K1 K2 K3];

L=ModelInfo.L;

Kpred = psi*(L'\(L\y));

alpha = (L'\(L\psi'));

Kvar = kuu(x_star, x_star, hyp, 0) - psi*alpha + alpha'*S*alpha;


