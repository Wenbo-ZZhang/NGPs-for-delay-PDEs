close all;
set(0,'defaulttextinterpreter','latex')
addpath ./export_fig
e = 0:0.05:0.5;
error_2 = load("noise_2.txt");
error_6 = load("noise_6.txt");
error_10 = load("noise_10.txt");
semilogy(e,error_2,'-+k', e,error_6,'-ob', e,error_10,'-*r','LineWidth', 2, 'MarkerSize', 5);
axis square
axis tight
h = legend('$E_{\infty}$($t = 0.2$)','$E_{\infty}$($t = 0.6$)','$E_{\infty}$($t = 1.0$)','Location','SouthEast');
set(h,'Interpreter','latex');
xlabel('$\sigma$')
ylabel('Error')
set(gca,'FontName','Times New Roman','FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('Impact of data noise on $E_{\\infty}$');
%title(tit);
