function [f] = P(x)

    f = 1+x.^2;
    
end