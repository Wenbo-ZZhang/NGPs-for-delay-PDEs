clc
close all
set(0,'defaulttextinterpreter','latex')
nn = 20;
Ntr = 5:5+nn-1;
error_1 = load("error_1.txt");
error_2 = load("error_2.txt");
error_3 = load("error_3.txt");
semilogy(Ntr(1:20),error_1(1:20),'+-k', Ntr(1:20),error_2(1:20),'o-b', Ntr(1:20),error_3(1:20),'*-r','LineWidth', 2, 'MarkerSize', 5);
axis square
axis tight
h = legend('max$E_{\infty}$($\Delta t = 10^{-1}$)','max$E_{\infty}$($\Delta t = 10^{-2}$)','max$E_{\infty}$($\Delta t = 10^{-3}$)','Location','NorthEast');
set(h,'Interpreter','latex');
xlabel('number of data points')
ylabel('Error')
set(gca,'FontName','Times New Roman','FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('Impact of the number of training data on $E_{\\infty}$');
%title(tit);