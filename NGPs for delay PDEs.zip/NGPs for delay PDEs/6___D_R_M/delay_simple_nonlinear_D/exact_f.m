function [f] = exact_f(x, t, tau)

f = exp(1).^((-3).*t).*(cos(x)+sin(x)).*(1+(-1).*exp(1).^(t+tau).*x.* ...
  cos(x)+exp(1).^(t+tau).*x.*sin(x)+sin(2.*x)+exp(1).^(2.*t).*(2.*x+ ...
  sin(exp(1).^((-1).*t).*(cos(x)+sin(x)))));

end