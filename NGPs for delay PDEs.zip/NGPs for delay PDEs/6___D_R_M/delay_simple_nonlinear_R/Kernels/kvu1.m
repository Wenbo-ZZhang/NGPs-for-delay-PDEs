function K=kvu1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;

u = ModelInfo.u;
logsigmau = hyp(1);
logthetau = hyp(2);


n_x = size(x,1);
n_y = size(y,1);

%unx = (u.^2)*ones(1,n_y)+sin(u)*ones(1,n_y)+2.*x*ones(1,n_y)+1;
uny = ones(n_x,1)*(u.^2)'+ones(n_x,1)*sin(u')+2.*ones(n_x,1)*y'+1;

x = x*ones(1,n_y);
y = ones(n_x,1)*y';


if i==0
    
    K = (-1).*dt.*uny.*(3.*exp(1).^(logsigmau+(-2).*logthetau+(-1/2).*exp( ...
  1).^((-1).*logthetau).*(x+(-1).*y).^2).*(x+(-1).*y)+(-1).*exp(1) ...
  .^(logsigmau+(-3).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*( ...
  x+(-1).*y).^2).*(x+(-1).*y).^3)+(-1).*exp(1).^(logsigmau+(-1).* ...
  logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(x+( ...
  -1).*y);
    K = real(K);

elseif i== 1
    
    K = (-1).*dt.*uny.*(3.*exp(1).^(logsigmau+(-2).*logthetau+(-1/2).*exp( ...
  1).^((-1).*logthetau).*(x+(-1).*y).^2).*(x+(-1).*y)+(-1).*exp(1) ...
  .^(logsigmau+(-3).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*( ...
  x+(-1).*y).^2).*(x+(-1).*y).^3)+(-1).*exp(1).^(logsigmau+(-1).* ...
  logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(x+( ...
  -1).*y);
    K = real(K);
    
elseif i== 2
    
    K = (-1).*dt.*uny.*(3.*exp(1).^(logsigmau+(-2).*logthetau+(-1/2).*exp( ...
  1).^((-1).*logthetau).*(x+(-1).*y).^2).*((-2)+(1/2).*exp(1).^((-1) ...
  .*logthetau).*(x+(-1).*y).^2).*(x+(-1).*y)+(-1).*exp(1).^( ...
  logsigmau+(-3).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+( ...
  -1).*y).^2).*((-3)+(1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y) ...
  .^2).*(x+(-1).*y).^3)+(-1).*exp(1).^(logsigmau+(-1).*logthetau+( ...
  -1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*((-1)+(1/2).* ...
  exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(x+(-1).*y);

    K = real(K);
    
else
    K = zeros(n_x,n_y);
end

end