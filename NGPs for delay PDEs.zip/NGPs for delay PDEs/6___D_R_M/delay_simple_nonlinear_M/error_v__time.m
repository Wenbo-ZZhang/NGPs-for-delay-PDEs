set(0,'defaulttextinterpreter','latex')
addpath ./export_fig
T = 1;
dt = 0.01;
dx = 0.1;






nsteps = T/dt;
D=load('error.txt');
D1=load('error1.txt');
%semilogy((1:nsteps)*dt,data,'b','LineWidth',3);
%semilogy((1:nsteps)*dt,D,'b',(1:nsteps)*dt, (1:nsteps)*dt,'--r','LineWidth',3);
semilogy((1:nsteps)*dt,D,'b',(1:nsteps)*dt,D1,'r','LineWidth',2);
%plot((1:nsteps)*dt,D,'b','LineWidth',3);
%hold
%plot((1:nsteps)*dt,D,'y','LineWidth',3);
%plot((1:nsteps)*dt,R,'g','LineWidth',3);
%plot((1:nsteps)*dt,M,'r','LineWidth',3);
xlabel('$t$')
ylabel('Error')
axis tight
ylim([0 0.05]);


set(gcf,'unit','normalized','position',[0.2,0.2,0.45,0.4]);


%h = legend('Error','$\Delta{t}$','Location', 'SouthEast');
%h = legend('$L_{2}$-$error$','$E_{\infty}$','Location', 'NorthEast');
h = legend('$L_{2}$','$E_{\infty}$','Location', 'NorthEast');
set(h,'Interpreter','latex');
%axis tight
set(gca,'FontName','Times New Roman','FontSize',14);
set(gcf, 'Color', 'w');

%tit = sprintf('Time versus relative spatial $L_{2}$-$error$ and maximum error $E_{\\infty}$');
%title(tit);