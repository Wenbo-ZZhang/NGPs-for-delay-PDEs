function E = main_noise(noise,T)
%function main()

clc; close all;

addpath ./Utilities
addpath ./Exact
addpath ./Kernels
addpath ./export_fig





rng('default')
%rng('shuffle')
global ModelInfo

set(0,'defaulttextinterpreter','latex')

%% Setup
Ntr = 10;
Ntr_artificial_u = Ntr;
Ntr_artificial_t = Ntr;
Ntr_artificial_f = Ntr;

dim = 1;
lb = 0*ones(1,dim);
ub = 2*pi*ones(1,dim);

jitter = 1e-8;
ModelInfo.jitter=jitter;
%noise_u = 0.5;
%noise_t = 0.5;
%noise_f = 0.25;
noise_u = noise;
noise_t = noise;
noise_f = noise/2;

plt = 0;

dt = 0.01;

ModelInfo.dt = dt;


tau = 0.2;
eta = tau/dt;




nsteps = T/dt;
error = zeros(1,nsteps);
error1 = zeros(1,nsteps);

%% Optimize model

ModelInfo.x_u = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr,dim)    ,(ub-lb)));%拉丁超立方采样 初始采点
ModelInfo.u = InitialCondition(ModelInfo.x_u);%初始边界点
ModelInfo.u = ModelInfo.u + noise_u*randn(size(ModelInfo.u));%加噪声
x_f = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_f,dim) ,(ub-lb)));%采点，为下一步做准备
ModelInfo.x_f = x_f;
f = exact_f(x_f,dt,tau);
ModelInfo.f = f + noise_f*randn(size(ModelInfo.u));
ModelInfo.K0 = zeros(Ntr);%存储上一步的协方差
ModelInfo.Kt = zeros(Ntr);

ModelInfo.lbx1 = 4+dt;
ModelInfo.lbx2 = 1+dt^2;
ModelInfo.lby1 = 4+dt;
ModelInfo.lby2 = 1+dt^2;
ModelInfo.ubx1 = (dt+1)^2;
ModelInfo.ubx2 = 2*sin(dt)+3;
ModelInfo.uby1 = (dt+1)^2;
ModelInfo.uby2 = 2*sin(dt)+3;

X = zeros(nsteps*Ntr,1);
U = zeros(nsteps*Ntr,1);
K = zeros(nsteps*Ntr,Ntr);

x_t = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_t,dim) ,(ub-lb)));%采点，为下一步做准备
ModelInfo.x_t = x_t;
u_t = exact_u(x_t,dt-tau);
ModelInfo.u_t = u_t + noise_t*randn(size(ModelInfo.u));

ModelInfo.x_lb = 0;
ModelInfo.x_ub = 2*pi;
ModelInfo.w_lb = exact_w(ModelInfo.x_lb,dt,1);
ModelInfo.w_ub = exact_w(ModelInfo.x_ub,dt,2);

ModelInfo.hyp = log([ones(1,6) exp(-6)]);

xstar = linspace(0,2*pi,400)';%平分区间

num_plots = 5;
fig = figure(1);
set(fig,'units','normalized','outerposition',[0 0 1 0.5])

clf
color2 = [95,217,2]/255;
k = 0;

for i = 1:nsteps
    
    [ModelInfo.hyp,~,~] = minimize(ModelInfo.hyp, @likelihood, -5000);%training
    
    [NLML,~]=likelihood(ModelInfo.hyp);
    [Kpred, Kvar] = predictor(xstar);%利用上一步的点预测下一步
    Kvar = abs(diag(Kvar));
    Exact = exact_u( xstar, i*dt );
    error(i) = norm(Kpred-Exact,2)/norm(Exact,2);
    error1(i) = norm(Kpred-Exact,inf);
    
    fprintf(1,'Step: %d, Time = %f, NLML = %e, error_u = %e\n', i, i*dt, NLML, error1(i));   
    
    x_u = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_u,dim) ,(ub-lb)));%采点，为下一步做准备
    [ModelInfo.u, ModelInfo.K0] = predictor(x_u);%记录这一采点对应的均值和方差
    ModelInfo.x_u = x_u;%记录这一采点
    
    X((i-1)*Ntr+1:i*Ntr,:) = ModelInfo.x_u;
    U((i-1)*Ntr+1:i*Ntr,:) = ModelInfo.u;
    K((i-1)*Ntr+1:i*Ntr,:) = ModelInfo.K0;
    
    ModelInfo.lbx1 = 4+(i+1)*dt;
    ModelInfo.lbx2 = 1+((i+1)*dt)^2;
    ModelInfo.lby1 = 4+(i+1)*dt;
    ModelInfo.lby2 = 1+((i+1)*dt)^2;
    ModelInfo.ubx1 = ((i+1)*dt+1)^2;
    ModelInfo.ubx2 = 2*sin((i+1)*dt)+3;
    ModelInfo.uby1 = ((i+1)*dt+1)^2;
    ModelInfo.uby2 = 2*sin((i+1)*dt)+3;
    
    ModelInfo.w_lb = exact_w(ModelInfo.x_lb,(i+1)*dt,1);
    ModelInfo.w_ub = exact_w(ModelInfo.x_ub,(i+1)*dt,2);
    
    if i>=eta   
        ModelInfo.x_t = X((i-eta)*Ntr+1:(i-eta+1)*Ntr,:);
        ModelInfo.u_t = U((i-eta)*Ntr+1:(i-eta+1)*Ntr,:);
        ModelInfo.Kt = K((i-eta)*Ntr+1:(i-eta+1)*Ntr,:);
    else
        x_t = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_t,dim) ,(ub-lb)));%采点，为下一步做准备
        ModelInfo.x_t = x_t;
        u_t = exact_u(x_t,(i+1)*dt-tau);
        ModelInfo.u_t = u_t + noise_t*randn(size(ModelInfo.u));
        ModelInfo.Kt = zeros(Ntr,Ntr);
    end
    

    
    x_f = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_f,dim) ,(ub-lb)));%采点，为下一步做准备
    ModelInfo.x_f = x_f;
    f = exact_f(x_f,(i+1)*dt,tau);
    ModelInfo.f = f + noise_f*randn(size(ModelInfo.u));
    
    %if plt == 1 && mod(i,floor(nsteps/(2*num_plots-1)))==0%plt == 1 && mod(i,floor(nsteps/(2*num_plots-1)))==0
    if plt == 1 && mod(i,20)==0%plt == 1 && mod(i,floor(nsteps/(2*num_plots-1)))==0
        k = k+1;
        subplot(1,num_plots,k)
        hold
        plot(xstar,Exact,'r','LineWidth',2);
        plot(xstar, Kpred,'b--','LineWidth',2);
        [l,p] = boundedline(xstar, Kpred, 2.0*sqrt(Kvar), ':', 'alpha','cmap', color2);
        outlinebounds(l,p);
        xlabel('$0 \leq x \leq 2\pi$')
        ylabel('$u(t,x)$')
        axis square
        %ylim([-1.5 1.5]);
       
        
        
        
        %set(gca, 'XTick', sort(ModelInfo.x_u));
        set(gca,'TickLength',[0.05 0.05]);
        set(gca, 'XTickLabel', [])
        set(gca,'FontSize',14);
        set(gcf, 'Color', 'w');
        
        set(gcf,'unit','normalized','position',[0,0,0.64*1.2,0.45*1.2]);
        
        %tit = sprintf('Time: %.2f\n%d artificial data', i*dt,Ntr_artificial_u);
        %tit = sprintf('t = %.2f\nerror = %d', i*dt,error(i));
        
        %formatSpec = 't = %.2f\n$E\\infty$ = %d';
        %tit = sprintf(formatSpec,i*dt,error(i));

        tit = sprintf('t = %.2f\n$E_{\\infty}$ = %.3e', i*dt,error1(i));
        title(tit);
        
        drawnow;
    end
    
    
    
end
%set(fig,'units','normalized','outerposition',[0 0 0.8 0.35])

E = error1(end);

save error.txt -ascii error
save error1.txt -ascii error1

rmpath ./Utilities
rmpath ./Exact
rmpath ./Kernels
rmpath ./export_fig