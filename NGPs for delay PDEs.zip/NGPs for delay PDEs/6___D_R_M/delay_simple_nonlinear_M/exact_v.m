function [f] = exact_v( x, t )

    f = exp(1).^((-1).*t).*(cos(x)+(-1).*sin(x));
end

