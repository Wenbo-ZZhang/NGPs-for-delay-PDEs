clc
e1 = load("error1.txt");
dt = 0.05;
for i = 1:(1/dt)
    if mod(i,(0.2/dt))==0
        sprintf('e=%.6e e1=%.6e', e1(i))
    end
end

E=load('error1.txt');
a=max(E);

sprintf('max = %.6e', a)