function [f] = exact_w( x, t, c)
    if c == 1
        f = exp(1).^((-1).*t).*(4+t).*(cos(x)+(-1).*sin(x))+exp(1).^((-1).*t) ...
  .*(1+t.^2).*(cos(x)+sin(x));
    elseif c == 2 
        f = exp(1).^((-1).*t).*(1+t).^2.*(cos(x)+(-1).*sin(x))+exp(1).^((-1).* ...
  t).*(3+2.*sin(t)).*(cos(x)+sin(x));
    end
    
end

