clc
clear all;
e_t = 0:0.1:0.5;
e_f = 0:0.1:0.5;
nn = length(e_t);
error_noise = zeros(nn,nn);

for i = 1:nn
    for j = 1:nn
        error_noise(i,j) = main_noise(e_t(i),e_f(j),0.5);
    end
end

error_noise

save error_noise.txt -ascii error_noise