function [ f ] = InitialCondition( x )

    f = cos(x)+sin(x);
end