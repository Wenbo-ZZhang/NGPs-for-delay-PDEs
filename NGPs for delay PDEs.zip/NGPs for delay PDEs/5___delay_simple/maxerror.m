clc
E=load('error1.txt');
a=max(E);

sprintf('t = %.6e', a)
