function K=kt1u1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
u = ModelInfo.u;

logsigmat1 = hyp(3);
logthetat1 = hyp(4);

n_x = size(x,1);
n_y = size(y,1);

gx = u*ones(1,n_y)-1;
gy = ones(n_x,1)*u'-1;

x = x*ones(1,n_y);
y = ones(n_x,1)*y';


if i==0
    
    K = dt.*exp(1).^(logsigmat1+(-2).*logthetat1+(-1/2).*exp(1).^((-1).* ...
  logthetat1).*(x+(-1).*y).^2).*gy.*(exp(1).^logthetat1+(-1).*(x+( ...
  -1).*y).^2);
    
elseif i== 3
    
    K = dt.*exp(1).^(logsigmat1+(-2).*logthetat1+(-1/2).*exp(1).^((-1).* ...
  logthetat1).*(x+(-1).*y).^2).*gy.*(exp(1).^logthetat1+(-1).*(x+( ...
  -1).*y).^2);
    
elseif i== 4
    
    K = dt.*exp(1).^(logsigmat1+(-1).*logthetat1+(-1/2).*exp(1).^((-1).* ...
  logthetat1).*(x+(-1).*y).^2).*gy+dt.*exp(1).^(logsigmat1+(-2).* ...
  logthetat1+(-1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2).* ...
  gy.*(exp(1).^logthetat1+(-1).*(x+(-1).*y).^2).*((-2)+(1/2).*exp(1) ...
  .^((-1).*logthetat1).*(x+(-1).*y).^2);

else
    K = zeros(n_x,n_y);
end

end