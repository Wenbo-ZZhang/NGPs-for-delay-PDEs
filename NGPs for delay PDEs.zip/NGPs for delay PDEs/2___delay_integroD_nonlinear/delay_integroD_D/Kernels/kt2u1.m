function K=kt2u1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
u = ModelInfo.u;

logsigmat2 = hyp(5);
logthetat2 = hyp(6);

n_x = size(x,1);
n_y = size(y,1);

hx = u*ones(1,n_y)+1;
hy = ones(n_x,1)*u'+1;

x = x*ones(1,n_y);
y = ones(n_x,1)*y';


if i==0
    
    K = dt.*exp(1).^(logsigmat2+(-3).*logthetat2+(-1/2).*exp(1).^((-1).* ...
  logthetat2).*(x+(-1).*y).^2).*hy.*(3.*exp(1).^logthetat2+(-1).*(x+ ...
  (-1).*y).^2).*(x+(-1).*y);
    
elseif i== 5
    
    K = dt.*exp(1).^(logsigmat2+(-3).*logthetat2+(-1/2).*exp(1).^((-1).* ...
  logthetat2).*(x+(-1).*y).^2).*hy.*(3.*exp(1).^logthetat2+(-1).*(x+ ...
  (-1).*y).^2).*(x+(-1).*y);
    
elseif i== 6
    
    K = 3.*dt.*exp(1).^(logsigmat2+(-2).*logthetat2+(-1/2).*exp(1).^((-1) ...
  .*logthetat2).*(x+(-1).*y).^2).*hy.*(x+(-1).*y)+dt.*exp(1).^( ...
  logsigmat2+(-3).*logthetat2+(-1/2).*exp(1).^((-1).*logthetat2).*( ...
  x+(-1).*y).^2).*hy.*(3.*exp(1).^logthetat2+(-1).*(x+(-1).*y).^2).* ...
  ((-3)+(1/2).*exp(1).^((-1).*logthetat2).*(x+(-1).*y).^2).*(x+(-1) ...
  .*y);

else
    K = zeros(n_x,n_y);
end

end