function K=kt1t1(x, y, hyp, i)

logsigmat1 = hyp(3);
logthetat1 = hyp(4);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';

if i==0
    
    K = exp(1).^(logsigmat1+(-1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2);
    
elseif i== 3
    
    K = exp(1).^(logsigmat1+(-1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2);
    
elseif i== 4
    
    K = (1/2).*exp(1).^(logsigmat1+(-1).*logthetat1+(-1/2).*exp(1).^((-1).*logthetat1).*(x+(-1).*y).^2).*(x+(-1).*y).^2;
else
    K = zeros(n_x,n_y);
end

end