function [f] = exact_u( x, t )

    f = (1+t.^2).*(2+(-1).*x.^3);
end

