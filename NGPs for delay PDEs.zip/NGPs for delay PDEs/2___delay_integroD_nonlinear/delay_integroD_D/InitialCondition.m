function [ f ] = InitialCondition( x )
    t = 0;
    f = (1+t.^2).*(2+(-1).*x.^3);
end