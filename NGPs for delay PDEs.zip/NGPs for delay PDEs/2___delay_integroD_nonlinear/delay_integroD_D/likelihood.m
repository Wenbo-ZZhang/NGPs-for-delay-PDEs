function [NLML,D_NLML]=likelihood(hyp)

global ModelInfo
x_u = ModelInfo.x_u;
x_b = ModelInfo.x_b;
x_f = ModelInfo.x_f;
x_t1 = ModelInfo.x_t1;
x_t2 = ModelInfo.x_t2;

u_t1 = ModelInfo.u_t1;
u_t2 = ModelInfo.u_t2;
f = ModelInfo.f;
u = ModelInfo.u;
u_b = ModelInfo.u_b;

y=[u_b; u_t1; u_t2; f; u];

jitter = ModelInfo.jitter;

sigma_n = exp(hyp(end));
   
n_u = size(x_u, 1);
n_f = size(x_f, 1);
n_b = size(x_b, 1);
n_t1 = size(x_t1, 1);
n_t2 = size(x_t2, 1);
n = n_b + n_t1 + n_t2 + n_f + n_u;

Kuu = kuu(x_b, x_b, hyp, 0);
Kt1t1 = kt1t1(x_t1, x_t1, hyp, 0);
Kt2t2 = kt2t2(x_t2, x_t2, hyp, 0);
Kff = kff(x_f, x_f, hyp, 0);

Kuu1 = kuu1(x_b, x_u, hyp, 0);
Kt1u1 = kt1u1(x_t1, x_u, hyp, 0);
Kt2u1 = kt2u1(x_t2, x_u, hyp, 0);
Kfu1 = kfu1(x_f, x_u, hyp, 0);

Ku1u1 = ku1u1(x_u, x_u, hyp, 0) + eye(n_u).*sigma_n;

K = [Kuu              zeros(n_b, n_t1)  zeros(n_b, n_t2)  zeros(n_b, n_f)  Kuu1;
     zeros(n_t1, n_b) Kt1t1             zeros(n_t1, n_t2) zeros(n_t1, n_f) Kt1u1;
     zeros(n_t2, n_b) zeros(n_t2, n_t1) Kt2t2             zeros(n_t2, n_f) Kt2u1;
     zeros(n_f, n_b)  zeros(n_f, n_t1)  zeros(n_f, n_t2)  Kff              Kfu1;
     Kuu1'            Kt1u1'            Kt2u1'            Kfu1'            Ku1u1];

K = K + eye(n).*jitter;

% Cholesky factorisation
[L,p]=chol(K,'lower');

ModelInfo.L = L;

if p > 0
    fprintf(1,'Covariance is ill-conditioned\n');
    size(L)
    size(K)
end

alpha = L'\(L\y);
NLML = 0.5*y'*alpha + sum(log(diag(L))) + log(2*pi)*n/2;


D_NLML = 0*hyp;
Q =  L'\(L\eye(n)) - alpha*alpha';
for i=1:8
    
    Kuu = kuu(x_b, x_b, hyp, i);
    Kt1t1 = kt1t1(x_t1, x_t1, hyp, i);
    Kt2t2 = kt2t2(x_t2, x_t2, hyp, i);
    Kff = kff(x_f, x_f, hyp, i);

    Kuu1 = kuu1(x_b, x_u, hyp, i);
    Kt1u1 = kt1u1(x_t1, x_u, hyp, i);
    Kt2u1 = kt2u1(x_t2, x_u, hyp, i);
    Kfu1 = kfu1(x_f, x_u, hyp, i);

    Ku1u1 = ku1u1(x_u, x_u, hyp, i);
    
    DK = [Kuu              zeros(n_b, n_t1)  zeros(n_b, n_t2)  zeros(n_b, n_f)  Kuu1;
          zeros(n_t1, n_b) Kt1t1             zeros(n_t1, n_t2) zeros(n_t1, n_f) Kt1u1;
          zeros(n_t2, n_b) zeros(n_t2, n_t1) Kt2t2             zeros(n_t2, n_f) Kt2u1;
          zeros(n_f, n_b)  zeros(n_f, n_t1)  zeros(n_f, n_t2)  Kff              Kfu1;
          Kuu1'            Kt1u1'            Kt2u1'            Kfu1'            Ku1u1];

    D_NLML(i) = sum(sum(Q.*DK))/2;
end

D_NLML(end) = sigma_n*trace(Q(n_b+n_t1+n_t2+n_f+1:end,n_b+n_t1+n_t2+n_f+1:end))/2;