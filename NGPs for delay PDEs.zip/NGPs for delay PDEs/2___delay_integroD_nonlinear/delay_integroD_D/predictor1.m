function [Kpred, Kvar] = predictor(x_star)

global ModelInfo
x_u = ModelInfo.x_u;
x_b = ModelInfo.x_b;
x_f = ModelInfo.x_f;
x_t1 = ModelInfo.x_t1;
x_t2 = ModelInfo.x_t2;

u_t1 = ModelInfo.u_t1;
u_t2 = ModelInfo.u_t2;
f = ModelInfo.f;
u = ModelInfo.u;
v_b = ModelInfo.v_b;

y=[v_b; u_t1; u_t2; f; u];

n_star = size(x_star,1);
n_u = size(x_u, 1);
n_f = size(x_f, 1);
n_b = size(x_b, 1);
n_t1 = size(x_t1, 1);
n_t2 = size(x_t2, 1);

K0 = ModelInfo.K0;
Kt1 = ModelInfo.Kt1;
Kt2 = ModelInfo.Kt2;

S = [zeros(n_b, n_b)  zeros(n_b, n_t1)  zeros(n_b, n_t2)  zeros(n_b, n_f)  zeros(n_b, n_u);
     zeros(n_t1, n_b) Kt1               zeros(n_t1, n_t2) zeros(n_t1, n_f) zeros(n_t1, n_u);
     zeros(n_t2, n_b) zeros(n_t2, n_t1) Kt2               zeros(n_t2, n_f) zeros(n_t2, n_u);
     zeros(n_f, n_b)  zeros(n_f, n_t1)  zeros(n_f, n_t2)  zeros(n_f, n_f)  zeros(n_f, n_u);
     zeros(n_u,n_b)   zeros(n_u, n_t1)  zeros(n_u,n_t2)   zeros(n_u,n_f)   K0];

hyp = ModelInfo.hyp;

K1 = kvu(x_b, x_star, hyp, 0);
K1 = K1';
K2 = zeros(n_star,n_t1);
K3 = zeros(n_star,n_t2);
K4 = zeros(n_star,n_f);
K5 = kuu1(x_star, x_u, hyp, 0);

psi = [K1 K2 K3 K4 K5];

L=ModelInfo.L;

Kpred = psi*(L'\(L\y));

alpha = (L'\(L\psi'));

Kvar = kuu(x_star, x_star, hyp, 0) - psi*alpha + alpha'*S*alpha;


