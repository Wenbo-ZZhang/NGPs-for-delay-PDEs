clc
e1 = load("error1.txt");
for i = 1:100
    if mod(i,10)==0
        sprintf('e=%.6e e1=%.6e', e1(i))
    end
end