function [f] = exact_v( x, t )

    f = (-3).*(1+t.^2).*x.^2;
end

