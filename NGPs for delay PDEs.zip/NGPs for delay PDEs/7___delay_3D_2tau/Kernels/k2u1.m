function K=k2u1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
logsigma2 = hyp(9);
logtheta12 = hyp(10);
logtheta22 = hyp(11);
logtheta32 = hyp(12);

n_x = size(x,1);
n_y = size(y,1);

x1 = x(:,1)*ones(1,n_y);
x2 = x(:,2)*ones(1,n_y);
x3 = x(:,3)*ones(1,n_y);

y1 = ones(n_x,1)*y(:,1)';
y2 = ones(n_x,1)*y(:,2)';
y3 = ones(n_x,1)*y(:,3)';


if i==0
    
    K = (-1).*dt.*exp(1).^(logsigma2+(-1).*logtheta22+(1/2).*((-1).*exp(1).^((-1).*logtheta12).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta22).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta32).*(x3+(-1).*y3).^2)).*(x2+(-1).*y2);

elseif i== 9
    
    K = (-1).*dt.*exp(1).^(logsigma2+(-1).*logtheta22+(1/2).*((-1).*exp(1).^((-1).*logtheta12).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta22).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta32).*(x3+(-1).*y3).^2)).*(x2+(-1).*y2);

    
elseif i== 10
    
    K = (-1/2).*dt.*exp(1).^(logsigma2+(-1).*logtheta12+(-1).*logtheta22+(1/2).*((-1).*exp(1).^((-1).*logtheta12).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta22).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta32).*(x3+(-1).*y3).^2)).*(x1+(-1).*y1).^2.*(x2+(-1).*y2);

elseif i== 11
    
    K = (-1).*dt.*exp(1).^(logsigma2+(-1).*logtheta22+(1/2).*((-1).*exp(1).^((-1).*logtheta12).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta22).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta32).*(x3+(-1).*y3).^2)).*((-1)+(1/2).*exp(1).^((-1).*logtheta22).*(x2+(-1).*y2).^2).*(x2+(-1).*y2);

elseif i== 12
    
    K = (-1/2).*dt.*exp(1).^(logsigma2+(-1).*logtheta22+(-1).*logtheta32+(1/2).*((-1).*exp(1).^((-1).*logtheta12).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta22).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta32).*(x3+(-1).*y3).^2)).*(x2+(-1).*y2).*(x3+(-1).*y3).^2;

else
    K = zeros(n_x,n_y);
end

end