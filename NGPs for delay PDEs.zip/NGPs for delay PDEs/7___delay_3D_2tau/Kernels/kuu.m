function K=kuu(x, y, hyp, i)

logsigmau = hyp(1);
logtheta1u = hyp(2);
logtheta2u = hyp(3);
logtheta3u = hyp(4);

n_x = size(x,1);
n_y = size(y,1);

x1 = x(:,1)*ones(1,n_y);
x2 = x(:,2)*ones(1,n_y);
x3 = x(:,3)*ones(1,n_y);

y1 = ones(n_x,1)*y(:,1)';
y2 = ones(n_x,1)*y(:,2)';
y3 = ones(n_x,1)*y(:,3)';


if i==0
    
    K = exp(1).^(logsigmau+(1/2).*((-1).*exp(1).^((-1).*logtheta1u).*(x1+( ...
  -1).*y1).^2+(-1).*exp(1).^((-1).*logtheta2u).*(x2+(-1).*y2).^2+( ...
  -1).*exp(1).^((-1).*logtheta3u).*(x3+(-1).*y3).^2));
    
elseif i== 1
    
    K = exp(1).^(logsigmau+(1/2).*((-1).*exp(1).^((-1).*logtheta1u).*(x1+( ...
  -1).*y1).^2+(-1).*exp(1).^((-1).*logtheta2u).*(x2+(-1).*y2).^2+( ...
  -1).*exp(1).^((-1).*logtheta3u).*(x3+(-1).*y3).^2));
    
elseif i== 2
    
    K = (1/2).*exp(1).^(logsigmau+(-1).*logtheta1u+(1/2).*((-1).*exp(1).^( ...
  (-1).*logtheta1u).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).* ...
  logtheta2u).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta3u).*( ...
  x3+(-1).*y3).^2)).*(x1+(-1).*y1).^2;
elseif i== 3
    
    K = (1/2).*exp(1).^(logsigmau+(-1).*logtheta2u+(1/2).*((-1).*exp(1).^( ...
  (-1).*logtheta1u).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).* ...
  logtheta2u).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta3u).*( ...
  x3+(-1).*y3).^2)).*(x2+(-1).*y2).^2;
elseif i== 4
    
    K = (1/2).*exp(1).^(logsigmau+(-1).*logtheta3u+(1/2).*((-1).*exp(1).^( ...
  (-1).*logtheta1u).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).* ...
  logtheta2u).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta3u).*( ...
  x3+(-1).*y3).^2)).*(x3+(-1).*y3).^2;
else
    K = zeros(n_x,n_y);
end

end