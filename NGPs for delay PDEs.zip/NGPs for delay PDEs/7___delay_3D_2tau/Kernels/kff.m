function K=kff(x, y, hyp, i)

logsigmaf = hyp(13);
logtheta1f = hyp(14);
logtheta2f = hyp(15);
logtheta3f = hyp(16);

n_x = size(x,1);
n_y = size(y,1);

x1 = x(:,1)*ones(1,n_y);
x2 = x(:,2)*ones(1,n_y);
x3 = x(:,3)*ones(1,n_y);

y1 = ones(n_x,1)*y(:,1)';
y2 = ones(n_x,1)*y(:,2)';
y3 = ones(n_x,1)*y(:,3)';


if i==0
    
    K = exp(1).^(logsigmaf+(1/2).*((-1).*exp(1).^((-1).*logtheta1f).*(x1+( ...
  -1).*y1).^2+(-1).*exp(1).^((-1).*logtheta2f).*(x2+(-1).*y2).^2+( ...
  -1).*exp(1).^((-1).*logtheta3f).*(x3+(-1).*y3).^2));
    
elseif i== 13
    
    K = exp(1).^(logsigmaf+(1/2).*((-1).*exp(1).^((-1).*logtheta1f).*(x1+( ...
  -1).*y1).^2+(-1).*exp(1).^((-1).*logtheta2f).*(x2+(-1).*y2).^2+( ...
  -1).*exp(1).^((-1).*logtheta3f).*(x3+(-1).*y3).^2));
    
elseif i== 14
    
    K = (1/2).*exp(1).^(logsigmaf+(-1).*logtheta1f+(1/2).*((-1).*exp(1).^( ...
  (-1).*logtheta1f).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).* ...
  logtheta2f).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta3f).*( ...
  x3+(-1).*y3).^2)).*(x1+(-1).*y1).^2;
elseif i== 15
    
    K = (1/2).*exp(1).^(logsigmaf+(-1).*logtheta2f+(1/2).*((-1).*exp(1).^( ...
  (-1).*logtheta1f).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).* ...
  logtheta2f).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta3f).*( ...
  x3+(-1).*y3).^2)).*(x2+(-1).*y2).^2;
elseif i== 16
    
    K = (1/2).*exp(1).^(logsigmaf+(-1).*logtheta3f+(1/2).*((-1).*exp(1).^( ...
  (-1).*logtheta1f).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).* ...
  logtheta2f).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta3f).*( ...
  x3+(-1).*y3).^2)).*(x3+(-1).*y3).^2;
else
    K = zeros(n_x,n_y);
end

end