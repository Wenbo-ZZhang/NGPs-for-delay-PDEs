function K=k1u1(x, y, hyp, i)
global ModelInfo
dt = ModelInfo.dt;
logsigma1 = hyp(5);
logtheta11 = hyp(6);
logtheta21 = hyp(7);
logtheta31 = hyp(8);

n_x = size(x,1);
n_y = size(y,1);

x1 = x(:,1)*ones(1,n_y);
x2 = x(:,2)*ones(1,n_y);
x3 = x(:,3)*ones(1,n_y);

y1 = ones(n_x,1)*y(:,1)';
y2 = ones(n_x,1)*y(:,2)';
y3 = ones(n_x,1)*y(:,3)';


if i==0
    
    K = (-1).*dt.*exp(1).^(logsigma1+(-1).*logtheta11+(1/2).*((-1).*exp(1).^((-1).*logtheta11).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta21).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta31).*(x3+(-1).*y3).^2)).*(x1+(-1).*y1);
    
elseif i== 5
    
    K = (-1).*dt.*exp(1).^(logsigma1+(-1).*logtheta11+(1/2).*((-1).*exp(1).^((-1).*logtheta11).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta21).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta31).*(x3+(-1).*y3).^2)).*(x1+(-1).*y1);

    
elseif i== 6
    
    K = (-1).*dt.*exp(1).^(logsigma1+(-1).*logtheta11+(1/2).*((-1).*exp(1).^((-1).*logtheta11).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta21).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta31).*(x3+(-1).*y3).^2)).*((-1)+(1/2).*exp(1).^((-1).*logtheta11).*(x1+(-1).*y1).^2).*(x1+(-1).*y1);

elseif i== 7
    
    K = (-1/2).*dt.*exp(1).^(logsigma1+(-1).*logtheta11+(-1).*logtheta21+(1/2).*((-1).*exp(1).^((-1).*logtheta11).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta21).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta31).*(x3+(-1).*y3).^2)).*(x1+(-1).*y1).*(x2+(-1).*y2).^2;

elseif i== 8
    
    K = (-1/2).*dt.*exp(1).^(logsigma1+(-1).*logtheta11+(-1).*logtheta31+(1/2).*((-1).*exp(1).^((-1).*logtheta11).*(x1+(-1).*y1).^2+(-1).*exp(1).^((-1).*logtheta21).*(x2+(-1).*y2).^2+(-1).*exp(1).^((-1).*logtheta31).*(x3+(-1).*y3).^2)).*(x1+(-1).*y1).*(x3+(-1).*y3).^2;

else
    K = zeros(n_x,n_y);
end

end