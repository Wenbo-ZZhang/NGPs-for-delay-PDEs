function main()

clc; close all;

addpath ./Utilities
addpath ./Exact
addpath ./Kernels
addpath ./export_fig





rng('default')
%rng('shuffle')
global ModelInfo

set(0,'defaulttextinterpreter','latex')

%% Setup
Ntr = 20;
Ntr_artificial_u = Ntr;
Ntr_artificial_t1 = Ntr;
Ntr_artificial_t2 = Ntr;
Ntr_artificial_f = Ntr;
N_b = 5;
dim = 3;
lb = 0*ones(1,dim);
ub = 2*pi*ones(1,dim);
jitter = 1e-8;
ModelInfo.jitter=jitter;
noise = 0;

plt = 0;

T = 1;
dt = 0.01;

ModelInfo.dt = dt;

tau1 = 0.1;
tau2 = 0.2;
eta1 = tau1/dt;
eta2 = tau2/dt;

num_plots = 3;

nsteps = T/dt;
error = zeros(1,nsteps);
error1 = zeros(1,nsteps);

%% Optimize model

ModelInfo.x_u = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr,dim)    ,(ub-lb)));%拉丁超立方采样 初始采点
ModelInfo.u = InitialCondition(ModelInfo.x_u);%初始边界点
ModelInfo.u = ModelInfo.u + noise*randn(size(ModelInfo.u));%加噪声
x_f = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_f,dim) ,(ub-lb)));%采点，为下一步做准备
ModelInfo.x_f = x_f;
f = exact_f(x_f,dt);
ModelInfo.f = f;
ModelInfo.K0 = zeros(Ntr);%存储上一步的协方差
ModelInfo.K_11 = zeros(Ntr);
ModelInfo.K_22 = zeros(Ntr);

X = zeros(nsteps*Ntr,3);
U = zeros(nsteps*Ntr,1);
K = zeros(nsteps*Ntr,Ntr);

x_tau1 = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_t1,dim) ,(ub-lb)));%采点，为下一步做准备
ModelInfo.x_tau1 = x_tau1;
u_tau1 = exact_u(x_tau1,dt-tau1);
ModelInfo.u_tau1 = u_tau1;

x_tau2 = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_t2,dim) ,(ub-lb)));%采点，为下一步做准备
ModelInfo.x_tau2 = x_tau2;
u_tau2 = exact_u(x_tau2,dt-tau2);
ModelInfo.u_tau2 = u_tau2;

x_b_11 = [zeros(N_b,1) zeros(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
x_b_12 = [zeros(N_b,1) ones(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
x_b_13 = [ones(N_b,1) zeros(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
x_b_14 = [ones(N_b,1) ones(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
x_b_21 = [zeros(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) zeros(N_b,1)];
x_b_22 = [zeros(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) ones(N_b,1)];
x_b_23 = [ones(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) zeros(N_b,1)];
x_b_24 = [ones(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) ones(N_b,1)];
x_b_31 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) zeros(N_b,1)  zeros(N_b,1)];
x_b_32 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) zeros(N_b,1)  ones(N_b,1)];
x_b_33 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) ones(N_b,1)  zeros(N_b,1)];
x_b_34 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) ones(N_b,1)  ones(N_b,1)];

ModelInfo.x_b = [x_b_11;x_b_12;x_b_13;x_b_14;x_b_21;x_b_22;x_b_23;x_b_24;x_b_31;x_b_32;x_b_33;x_b_34;];
ModelInfo.u_b = exact_u(ModelInfo.x_b,dt);

ModelInfo.hyp = log([ones(1,16) exp(-6)]);

nn = 10;
xx1 = linspace(0, 1, nn)';
xx2 = linspace(0, 1, nn)';
xx3 = linspace(0, 1, nn)';
[Xplot, Yplot, Zplot] = meshgrid(xx1,xx2,xx3);
xstar = zeros(nn^3,3);
for i = 1:nn
    for j = 1:nn
        for k = 1:nn
            xstar((i-1)*nn*nn+(j-1)*nn+k,:) = [Xplot(i,j,k) Yplot(i,j,k) Zplot(i,j,k)];
        end
    end
end


for i = 1:nsteps
    [ModelInfo.hyp,~,~] = minimize(ModelInfo.hyp, @likelihood, -5000);%training
    
    [NLML,~]=likelihood(ModelInfo.hyp);
    [Kpred, Kvar] = predictor(xstar);%利用上一步的点预测下一步
    Kvar = abs(diag(Kvar));
    Exact = exact_u( xstar, i*dt );
    error(i) = norm(Kpred-Exact,2)/norm(Exact,2);
    error1(i) = norm(Kpred-Exact,inf);
    
    fprintf(1,'Step: %d, Time = %f, NLML = %e, error_u = %e, error_u = %e\n', i, i*dt, NLML, error(i), error1(i));   
    
    x_u = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_u,dim) ,(ub-lb)));%采点，为下一步做准备
    [ModelInfo.u, ModelInfo.K0] = predictor(x_u);%记录这一采点对应的均值和方差
    ModelInfo.x_u = x_u;%记录这一采点
    
    x_b_11 = [zeros(N_b,1) zeros(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
    x_b_12 = [zeros(N_b,1) ones(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
    x_b_13 = [ones(N_b,1) zeros(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
    x_b_14 = [ones(N_b,1) ones(N_b,1) bsxfun(@plus,lb(3),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(3)-lb(3))))];
    x_b_21 = [zeros(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) zeros(N_b,1)];
    x_b_22 = [zeros(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) ones(N_b,1)];
    x_b_23 = [ones(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) zeros(N_b,1)];
    x_b_24 = [ones(N_b,1) bsxfun(@plus,lb(2),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(2)-lb(2)))) ones(N_b,1)];
    x_b_31 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) zeros(N_b,1)  zeros(N_b,1)];
    x_b_32 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) zeros(N_b,1)  ones(N_b,1)];
    x_b_33 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) ones(N_b,1)  zeros(N_b,1)];
    x_b_34 = [bsxfun(@plus,lb(1),bsxfun(@times,   lhsdesign(N_b,1)    ,(ub(1)-lb(1)))) ones(N_b,1)  ones(N_b,1)];
    
    ModelInfo.x_b = [x_b_11;x_b_12;x_b_13;x_b_14;x_b_21;x_b_22;x_b_23;x_b_24;x_b_31;x_b_32;x_b_33;x_b_34;];
    
    ModelInfo.u_b = exact_u(ModelInfo.x_b,(i+1)*dt);
    
    X((i-1)*Ntr+1:i*Ntr,:) = ModelInfo.x_u;
    U((i-1)*Ntr+1:i*Ntr,:) = ModelInfo.u;
    K((i-1)*Ntr+1:i*Ntr,:) = ModelInfo.K0;
    
    if i>=eta1   
        ModelInfo.x_tau1 = X((i-eta1)*Ntr+1:(i-eta1+1)*Ntr,:);
        ModelInfo.u_tau1 = U((i-eta1)*Ntr+1:(i-eta1+1)*Ntr,:);
        ModelInfo.K_11 = K((i-eta1)*Ntr+1:(i-eta1+1)*Ntr,:);
    else
        x_tau1 = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_t1,dim) ,(ub-lb)));%采点，为下一步做准备
        ModelInfo.x_tau1 = x_tau1;
        u_tau1 = exact_u(x_tau1,(i+1)*dt-tau1);
        ModelInfo.u_tau1 = u_tau1;
        ModelInfo.K_11 = zeros(Ntr,Ntr);
    end
    
    if i>=eta2
        ModelInfo.x_tau2 = X((i-eta2)*Ntr+1:(i-eta2+1)*Ntr,:);
        ModelInfo.u_tau2 = U((i-eta2)*Ntr+1:(i-eta2+1)*Ntr,:);
        ModelInfo.K_22 = K((i-eta2)*Ntr+1:(i-eta2+1)*Ntr,:);
    else
        x_tau2 = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_t2,dim) ,(ub-lb)));%采点，为下一步做准备
        ModelInfo.x_tau2 = x_tau2;
        u_tau2 = exact_u(x_tau2,(i+1)*dt-tau2);
        ModelInfo.u_tau2 = u_tau2;
        ModelInfo.K_22 = zeros(Ntr,Ntr);
    end
    
    x_f = bsxfun(@plus,lb,bsxfun(@times,   lhsdesign(Ntr_artificial_f,dim) ,(ub-lb)));%采点，为下一步做准备
    ModelInfo.x_f = x_f;
    f = exact_f(x_f,(i+1)*dt);
    ModelInfo.f = f;

    
    
    
end

save error.txt -ascii error
save error1.txt -ascii error1

rmpath ./Utilities
rmpath ./Exact
rmpath ./Kernels
rmpath ./export_fig