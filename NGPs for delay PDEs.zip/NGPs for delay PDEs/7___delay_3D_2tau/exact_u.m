function [f] = exact_u( x, t )
    x1 = x(:,1);
    x2 = x(:,2);
    x3 = x(:,3);
    f = (1/10).*(5+sin(t)).*(cos(x1)+sin(x1)).*(cos(x2)+sin(x2)).*(cos(x3) ...
  +sin(x3));
end

