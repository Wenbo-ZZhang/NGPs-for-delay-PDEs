semilogy(dt,error,'-*r',10.^-(1:0.5:4),10.^-(1:0.5:4),'--k', 'LineWidth', 2, 'MarkerSize', 10);
axis square
axis tight
h = legend('$E_{\infty}$','$\Delta t$','Location','SouthEast');
set(h,'Interpreter','latex');
xlabel('$\Delta t$')
ylabel('$E_{\infty}$')
set(gca,'FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('t = 0.1');
title(tit);