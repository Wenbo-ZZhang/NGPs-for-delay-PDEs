x1 = 0:0.1:1;
x2 = 0:0.1:0.8;
[Xplot, Yplot] = meshgrid(x1,x2);    
error_noise = load("error_noise.txt");

    clf
    clear h
    clear leg
    
    hold
    contourf(Xplot,Yplot,error_noise(1:9,:),10);
    colormap('summer')
    %plot(ModelInfo.x_f(:,1), ModelInfo.x_f(:,2), 's', 'MarkerEdgeColor','k','MarkerSize',6,'LineWidth',1.5);
    %plot(ModelInfo.x_u(:,1), ModelInfo.x_u(:,2), 'o', 'MarkerEdgeColor','k','MarkerSize',6,'LineWidth',1.5);
    
    colorbar
    
        xlabel('$\sigma^0$')
        ylabel('$\sigma_b^n$')


    set(gca,'XTick',[0 0.5 1]);
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'FontName','Times New Roman','fontsize',14)
    set(gca,'YTick',[0 0.5 1]);
    axis square
    set(gca,'FontSize',14);
    set(gcf, 'Color', 'w');