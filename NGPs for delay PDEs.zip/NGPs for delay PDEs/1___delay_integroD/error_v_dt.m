set(0,'defaulttextinterpreter','latex')
addpath ./export_fig

nn = 6;
error = zeros(1,nn);
%Ntr = 30;
T = 0.5;
dt=zeros(1,nn);
for i = 1:nn
    dt(i) = 0.1/(2^(i-1));
    error(i) = main(dt(i),T);
end
%semilogy(dt,error,'-*b',10.^-(1:0.5:4),10.^-(1:0.5:4),'--or', 'LineWidth', 2, 'MarkerSize', 10);
semilogy(dt,error,'-*r',10.^-(1:0.5:4),10.^-(1:0.5:4),'--k', 'LineWidth', 2, 'MarkerSize', 10);
axis square
axis tight
h = legend('$E_{\infty}$','$\Delta t$','Location','SouthEast');
set(h,'Interpreter','latex');
xlabel('$\Delta t$')
ylabel('$E_{\infty}$')
set(gca,'FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('t = 0.1');
title(tit);

%export_fig ./Figures/Burgers_time_error.png -r300
% buf = sprintf('time_error_Ntr%d.txt', Ntr);
% save(buf,'-ascii','-double', 'error');

rmpath ./export_fig
