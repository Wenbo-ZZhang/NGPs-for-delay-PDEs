nn = 5;
xx1 = linspace(0, 1, nn)';
xx2 = linspace(0, 1, nn)';
xx3 = linspace(0, 1, nn)';
[Xplot, Yplot, Zplot] = meshgrid(xx1,xx2,xx3);
xstar = zeros(nn^3,3);
for i = 1:nn
    for j = 1:nn
        for k = 1:nn
            xstar((i-1)*nn*nn+(j-1)*nn+k,:) = [Xplot(i,j,k) Yplot(i,j,k) Zplot(i,j,k)];
        end
    end
end
%xstar = reshape([Xplot Yplot Zplot], nn^3, 2);
