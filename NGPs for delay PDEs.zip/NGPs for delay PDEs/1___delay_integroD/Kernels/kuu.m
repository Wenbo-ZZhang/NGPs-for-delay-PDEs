function K=kuu(x, y, hyp, i)

logsigmau = hyp(1);
logthetau = hyp(2);

n_x = size(x,1);
n_y = size(y,1);

x = x*ones(1,n_y);
y = ones(n_x,1)*y';

if i==0
    
    K = exp(1).^(logsigmau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2);
    
elseif i== 1
    
    K = exp(1).^(logsigmau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2);
    
elseif i== 2
    
    K = (1/2).*exp(1).^(logsigmau+(-1).*logthetau+(-1/2).*exp(1).^((-1).*logthetau).*(x+(-1).*y).^2).*(x+(-1).*y).^2;
else
    K = zeros(n_x,n_y);
end

end