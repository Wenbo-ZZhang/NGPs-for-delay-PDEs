T = 1;
dt = 0.01;
dx = 0.1;
alpha = 3;
ModelInfo.dt = dt;
ModelInfo.alpha = alpha;

num_plots = 3;

nsteps = T/dt;
D=load('errorD.txt');
R=load('errorR.txt');
M=load('errorM.txt');
size(D)
size(R)
%semilogy((1:nsteps)*dt,data,'b','LineWidth',3);
semilogy((1:nsteps)*dt,D,'b',(1:nsteps)*dt,R,'g',(1:nsteps)*dt,M,'y',(1:nsteps)*dt, (1:nsteps)*dt,'--r','LineWidth',3);
%hold
%plot((1:nsteps)*dt,D,'y','LineWidth',3);
%plot((1:nsteps)*dt,R,'g','LineWidth',3);
%plot((1:nsteps)*dt,M,'r','LineWidth',3);
xlabel('$t$')
ylabel('Error')
%h = legend('Error','$\Delta{t}$','Location', 'SouthEast');
h = legend('Error for $D$','Error for $R$','Error for $M$','$\Delta{t}$','Location', 'NorthEast');
set(h,'Interpreter','latex');
axis tight
set(gca,'FontSize',14);
set(gcf, 'Color', 'w');