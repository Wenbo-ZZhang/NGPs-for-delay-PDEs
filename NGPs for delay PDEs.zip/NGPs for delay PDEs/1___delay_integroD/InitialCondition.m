function [ f ] = InitialCondition( x )
    t = 0;
    f = (1+t.^3).*(2+(-1).*x.^2);
end