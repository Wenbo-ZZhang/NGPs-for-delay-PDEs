clc
clear all;
e_u = 0:0.1:0.3;
e_b = 0:0.1:0.3;
nn = length(e_u);
error_noise = zeros(nn,nn);

for i = 1:nn
    for j = 1:nn
        error_noise(i,j) = main_noise_new(e_u(i),e_b(j),0.3);
    end
end

error_noise

save error_noise.txt -ascii error_noise