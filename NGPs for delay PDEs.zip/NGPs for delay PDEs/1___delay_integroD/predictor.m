function [Kpred, Kvar] = predictor(x_star)

global ModelInfo
x_u = ModelInfo.x_u;
x_b = ModelInfo.x_b;
x_f = ModelInfo.x_f;
x_t = ModelInfo.x_t;

u_t = ModelInfo.u_t;
f = ModelInfo.f;
u = ModelInfo.u;
u_b = ModelInfo.u_b;

y=[u_b; u_t; f; u];

n_star = size(x_star,1);
n_u = size(x_u, 1);
n_f = size(x_f, 1);
n_b = size(x_b, 1);
n_t = size(x_t, 1);

K0 = ModelInfo.K0;
Kt = ModelInfo.Kt;



S = [zeros(n_b, n_b) zeros(n_b, n_t) zeros(n_b, n_f) zeros(n_b, n_u);
    zeros(n_t, n_b) Kt zeros(n_t, n_f) zeros(n_t, n_u);
    zeros(n_f, n_b) zeros(n_f, n_t) zeros(n_f, n_f) zeros(n_f, n_u);
    zeros(n_u,n_b) zeros(n_u,n_t) zeros(n_u,n_f) K0];

hyp = ModelInfo.hyp;


K1 = kuu(x_star, x_b, hyp, 0);
K2 = zeros(n_star,n_t);
K3 = zeros(n_star,n_f);
K4 = kuu1(x_star, x_u, hyp, 0);

psi = [K1 K2 K3 K4];

L=ModelInfo.L;

Kpred = psi*(L'\(L\y));

alpha = (L'\(L\psi'));

Kvar = kuu(x_star, x_star, hyp, 0) - psi*alpha + alpha'*S*alpha;


