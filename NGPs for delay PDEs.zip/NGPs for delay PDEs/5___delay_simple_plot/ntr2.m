set(0,'defaulttextinterpreter','latex')
nn = 40;
Ntr = 5:5+nn-1;
error_1 = load("error_1.txt");
error_2 = load("error_2.txt");
error_3 = load("error_3.txt");
semilogy(Ntr(1:19),error_1(1:19),'+-k', Ntr(1:19),error_2(1:19),'o-b', Ntr(1:19),error_3(1:19),'*-r','LineWidth', 2, 'MarkerSize', 5);
axis square
axis tight
h = legend('$E_{\infty}$ ($\Delta t = 10^{-1}$)','$E_{\infty}$ ($\Delta t = 10^{-2}$)','$E_{\infty}$ ($\Delta t = 10^{-3}$)','Location','SouthEast');
set(h,'Interpreter','latex');
xlabel('number of data points')
ylabel('Error')
set(gca,'FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('Impact of the number of training data on $E_{\\infty}$');
%title(tit);