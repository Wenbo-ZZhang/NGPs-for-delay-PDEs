set(0,'defaulttextinterpreter','latex')
addpath ./export_fig
e = 0:0.1:1;
nn = length(e);
error_2 = zeros(1,nn);
error_6 = zeros(1,nn);
error_10 = zeros(1,nn);

for i = 1:nn
    error_2(i) = main(e(i),0.2);
    error_6(i) = main(e(i),0.6);
    error_10(i) = main(e(i),1.0);
end
semilogy(e,error_2,'-b', e,error_6,'-k', e,error_10,'-r','LineWidth', 2, 'MarkerSize', 10);
axis square
axis tight
h = legend('$E_{\infty}$ ($\Delta t = 10^{-1}$)','$E_{\infty}$ ($\Delta t = 10^{-2}$)','$E_{\infty}$ ($\Delta t = 10^{-3}$)','Location','NorthEast');
set(h,'Interpreter','latex');
xlabel('number of data points')
ylabel('$E_{\infty}$')
set(gca,'FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('t = 0.2');
title(tit);


%export_fig ./Figures/Burgers_space_error.png -r300
% buf = sprintf('time_error_Ntr%d.txt', Ntr);
% save(buf,'-ascii','-double', 'error');

rmpath ./export_fig
