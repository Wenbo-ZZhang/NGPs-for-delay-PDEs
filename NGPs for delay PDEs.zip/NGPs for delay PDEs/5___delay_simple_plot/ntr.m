set(0,'defaulttextinterpreter','latex')
addpath ./export_fig

nn = 40;
error_1 = zeros(1,nn);
error_2 = zeros(1,nn);
error_3 = zeros(1,nn);
T = 1;
dt_1 = 10^-1;
dt_2 = 10^-2;
dt_3 = 10^-3;
Ntr = 5:5+nn-1;
for i = 1:nn
    error_1(i) = main(Ntr(i),dt_1,T);
    error_2(i) = main(Ntr(i),dt_2,T);
    error_3(i) = main(Ntr(i),dt_3,T);
end
semilogy(Ntr,error_1,'-b', Ntr,error_2,'-k', Ntr,error_3,'-r','LineWidth', 2, 'MarkerSize', 10);
axis square
axis tight
h = legend('$E_{\infty}$ ($\Delta t = 10^{-1}$)','$E_{\infty}$ ($\Delta t = 10^{-2}$)','$E_{\infty}$ ($\Delta t = 10^{-3}$)','Location','NorthEast');
set(h,'Interpreter','latex');
xlabel('number of data points')
ylabel('$E_{\infty}$')
set(gca,'FontSize',14);
set(gcf, 'Color', 'w');
tit = sprintf('t = 0.2');
title(tit);


%export_fig ./Figures/Burgers_space_error.png -r300
% buf = sprintf('time_error_Ntr%d.txt', Ntr);
% save(buf,'-ascii','-double', 'error');

rmpath ./export_fig
